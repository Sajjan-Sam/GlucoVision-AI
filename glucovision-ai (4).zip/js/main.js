import * as lucide from "lucide"

document.addEventListener("DOMContentLoaded", () => {
  // Initialize Lucide icons
  lucide.createIcons()

  // Set current year in footer
  document.querySelectorAll("#currentYear").forEach((el) => {
    el.textContent = new Date().getFullYear()
  })

  // Mobile menu toggle
  const mobileMenuBtn = document.getElementById("mobileMenuBtn")
  const mobileNav = document.getElementById("mobileNav")

  if (mobileMenuBtn && mobileNav) {
    mobileMenuBtn.addEventListener("click", () => {
      mobileNav.classList.toggle("active")

      // Toggle menu icon
      const menuIcon = mobileMenuBtn.querySelector("i")
      if (menuIcon) {
        if (mobileNav.classList.contains("active")) {
          menuIcon.setAttribute("data-lucide", "x")
        } else {
          menuIcon.setAttribute("data-lucide", "menu")
        }
        lucide.createIcons()
      }
    })
  }
})
