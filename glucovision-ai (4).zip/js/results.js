document.addEventListener("DOMContentLoaded", () => {
  // Elements
  const loadingState = document.getElementById("loadingState")
  const errorState = document.getElementById("errorState")
  const resultsState = document.getElementById("resultsState")

  const riskLevelBadge = document.getElementById("riskLevelBadge")
  const confidenceValue = document.getElementById("confidenceValue")
  const findingsList = document.getElementById("findingsList")
  const glucoseValue = document.getElementById("glucoseValue")
  const recommendationsList = document.getElementById("recommendationsList")

  const riskScoreValue = document.getElementById("riskScoreValue")
  const glucoseLevelValue = document.getElementById("glucoseLevelValue")
  const confidencePercentValue = document.getElementById("confidencePercentValue")

  const healthTips = document.getElementById("healthTips")

  const voiceBtn = document.getElementById("voiceBtn")
  const downloadBtn = document.getElementById("downloadBtn")
  const shareBtn = document.getElementById("shareBtn")

  let isVoiceActive = false
  let resultData = null

  // Get results from localStorage
  const getResults = () => {
    try {
      const storedResults = localStorage.getItem("glucovisionResults")
      if (storedResults) {
        return JSON.parse(storedResults)
      }
      return null
    } catch (error) {
      console.error("Error parsing results:", error)
      return null
    }
  }

  // Create risk level badge
  const createRiskLevelBadge = (level) => {
    let icon, label, colorClass, description

    switch (level) {
      case "low":
        icon = "check-circle"
        label = "Low Risk"
        colorClass = "low-risk"
        description = "No significant signs of diabetic retinopathy detected."
        break
      case "medium":
        icon = "alert-circle"
        label = "Medium Risk"
        colorClass = "medium-risk"
        description = "Early signs of diabetic retinopathy may be present."
        break
      case "high":
        icon = "alert-triangle"
        label = "High Risk"
        colorClass = "high-risk"
        description = "Significant signs of diabetic retinopathy detected."
        break
      default:
        icon = "check-circle"
        label = "Low Risk"
        colorClass = "low-risk"
        description = "No significant signs of diabetic retinopathy detected."
    }

    return `
      <div class="risk-level-badge ${colorClass}">
        <div class="risk-badge-icon-wrapper">
          <i data-lucide="${icon}" class="risk-badge-icon"></i>
        </div>
        <h3 class="risk-badge-title">${label}</h3>
        <p class="risk-badge-description">${description}</p>
      </div>
    `
  }

  // Create health tips
  const createHealthTips = (riskLevel) => {
    let importantNote = ""

    if (riskLevel !== "low") {
      importantNote = `
        <div class="important-note">
          <div class="important-note-icon-wrapper">
            <i data-lucide="alert-triangle" class="important-note-icon"></i>
          </div>
          <div class="important-note-content">
            <h4>Important Note</h4>
            <p>
              ${
                riskLevel === "medium"
                  ? "Based on your results, we recommend scheduling an appointment with an eye care specialist within the next 3 months for a comprehensive evaluation."
                  : "Your results indicate a higher risk level. We strongly recommend consulting with an ophthalmologist within the next 30 days for a thorough examination and appropriate treatment plan."
              }
            </p>
          </div>
        </div>
      `
    }

    return `
      <h3 class="health-tips-title glow-text">Personalized Health Tips</h3>
      
      <div class="health-tips-grid">
        <div class="health-tip-card">
          <div class="health-tip-header">
            <div class="health-tip-icon-wrapper">
              <i data-lucide="salad" class="health-tip-icon"></i>
            </div>
            <h4 class="health-tip-title">Diet Recommendations</h4>
          </div>
          <ul class="health-tip-list">
            <li>• Focus on low-glycemic index foods to maintain stable blood sugar</li>
            <li>• Increase fiber intake through vegetables, fruits, and whole grains</li>
            <li>• Limit processed foods and added sugars</li>
            ${riskLevel !== "low" ? "<li>• Consider consulting with a dietitian for a personalized meal plan</li>" : ""}
          </ul>
        </div>
        
        <div class="health-tip-card">
          <div class="health-tip-header">
            <div class="health-tip-icon-wrapper">
              <i data-lucide="dumbbell" class="health-tip-icon"></i>
            </div>
            <h4 class="health-tip-title">Exercise Guidelines</h4>
          </div>
          <ul class="health-tip-list">
            <li>• Aim for at least 150 minutes of moderate activity per week</li>
            <li>• Include both aerobic exercise and strength training</li>
            <li>• Start slowly and gradually increase intensity</li>
            ${riskLevel === "high" ? "<li>• Consult with your doctor before starting a new exercise program</li>" : ""}
          </ul>
        </div>
        
        <div class="health-tip-card">
          <div class="health-tip-header">
            <div class="health-tip-icon-wrapper">
              <i data-lucide="heart-pulse" class="health-tip-icon"></i>
            </div>
            <h4 class="health-tip-title">Health Monitoring</h4>
          </div>
          <ul class="health-tip-list">
            ${
              riskLevel === "low"
                ? `
              <li>• Schedule regular eye exams annually</li>
              <li>• Monitor blood pressure and cholesterol levels</li>
            `
                : riskLevel === "medium"
                  ? `
              <li>• Schedule eye exams every 6 months</li>
              <li>• Consider regular blood glucose monitoring</li>
              <li>• Track blood pressure weekly</li>
            `
                  : `
              <li>• Consult with an ophthalmologist promptly</li>
              <li>• Monitor blood glucose levels daily</li>
              <li>• Schedule comprehensive diabetic check-ups</li>
            `
            }
          </ul>
        </div>
        
        <div class="health-tip-card">
          <div class="health-tip-header">
            <div class="health-tip-icon-wrapper">
              <i data-lucide="moon" class="health-tip-icon"></i>
            </div>
            <h4 class="health-tip-title">Lifestyle Adjustments</h4>
          </div>
          <ul class="health-tip-list">
            <li>• Prioritize 7-8 hours of quality sleep each night</li>
            <li>• Practice stress management techniques</li>
            <li>• Stay hydrated with at least 8 glasses of water daily</li>
            ${riskLevel === "medium" || riskLevel === "high" ? "<li>• Avoid smoking and limit alcohol consumption</li>" : ""}
          </ul>
        </div>
      </div>
      
      ${importantNote}
    `
  }

  // Populate findings list
  const populateFindingsList = (findings) => {
    findingsList.innerHTML = ""

    findings.forEach((finding) => {
      const li = document.createElement("li")
      li.innerHTML = `
        <i data-lucide="info" class="findings-icon"></i>
        <span>${finding}</span>
      `
      findingsList.appendChild(li)
    })

    lucide.createIcons()
  }

  // Populate recommendations list
  const populateRecommendationsList = (recommendations) => {
    recommendationsList.innerHTML = ""

    recommendations.forEach((recommendation) => {
      const li = document.createElement("li")
      li.innerHTML = `
        <i data-lucide="check-circle" class="recommendations-icon"></i>
        <span>${recommendation}</span>
      `
      recommendationsList.appendChild(li)
    })

    lucide.createIcons()
  }

  // Toggle voice narration
  const toggleVoice = () => {
    if (isVoiceActive) {
      // Stop voice
      window.speechSynthesis.cancel()
      isVoiceActive = false

      // Update icon
      voiceBtn.innerHTML = '<i data-lucide="volume-2"></i>'
      lucide.createIcons()
    } else {
      // Start voice narration
      if (resultData) {
        const speech = new SpeechSynthesisUtterance()
        speech.text = `
          Your GlucoVision AI analysis results show a ${resultData.riskLevel} risk level for diabetic retinopathy.
          Your estimated glucose level is approximately ${resultData.glucoseEstimation} mg/dL.
          Key findings include: ${resultData.findings.join(", ")}.
          Our recommendations are: ${resultData.recommendations.join(", ")}.
          Please remember this is an experimental tool and not a replacement for professional medical advice.
        `
        speech.rate = 0.9
        speech.pitch = 1
        speech.volume = 1

        window.speechSynthesis.speak(speech)
        isVoiceActive = true

        // Update icon
        voiceBtn.innerHTML = '<i data-lucide="volume-x"></i>'
        lucide.createIcons()

        speech.onend = () => {
          isVoiceActive = false
          voiceBtn.innerHTML = '<i data-lucide="volume-2"></i>'
          lucide.createIcons()
        }
      }
    }
  }

  // Download results as PDF (simulated)
  const downloadResults = () => {
    alert("This would download your results as a PDF in a real application.")
  }

  // Share results (simulated)
  const shareResults = () => {
    alert("This would share your results in a real application.")
  }

  // Initialize results page
  const initResultsPage = () => {
    // Simulate loading
    setTimeout(() => {
      // Get results data
      resultData = getResults()

      if (resultData) {
        // Hide loading state and show results
        loadingState.classList.add("hidden")
        resultsState.classList.remove("hidden")

        // Populate risk level badge
        riskLevelBadge.innerHTML = createRiskLevelBadge(resultData.riskLevel)

        // Populate confidence value
        confidenceValue.textContent = `${resultData.confidence}%`

        // Populate findings list
        populateFindingsList(resultData.findings)

        // Populate glucose value
        glucoseValue.innerHTML = `
          ${resultData.glucoseEstimation} <span class="glucose-unit">mg/dL</span>
        `

        // Populate recommendations list
        populateRecommendationsList(resultData.recommendations)

        // Populate data cards
        riskScoreValue.textContent = resultData.riskScore
        glucoseLevelValue.textContent = resultData.glucoseEstimation
        confidencePercentValue.textContent = `${resultData.confidence}%`

        // Populate health tips
        healthTips.innerHTML = createHealthTips(resultData.riskLevel)

        // Initialize icons
        lucide.createIcons()
      } else {
        // Show error state
        loadingState.classList.add("hidden")
        errorState.classList.remove("hidden")
      }
    }, 2000)
  }

  // Event listeners
  if (voiceBtn) {
    voiceBtn.addEventListener("click", toggleVoice)
  }

  if (downloadBtn) {
    downloadBtn.addEventListener("click", downloadResults)
  }

  if (shareBtn) {
    shareBtn.addEventListener("click", shareResults)
  }

  // Initialize page
  initResultsPage()

  // Import lucide icons
  lucide.createIcons()
})
