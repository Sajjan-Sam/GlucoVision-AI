document.addEventListener("DOMContentLoaded", () => {
  // Elements
  const video = document.getElementById("video")
  const canvas = document.getElementById("canvas")
  const capturedImage = document.getElementById("capturedImage")
  const startCameraBtn = document.getElementById("startCameraBtn")
  const captureBtn = document.getElementById("captureBtn")
  const retakeBtn = document.getElementById("retakeBtn")
  const analyzeBtn = document.getElementById("analyzeBtn")
  const cameraError = document.getElementById("cameraError")
  const tryAgainBtn = document.getElementById("tryAgainBtn")
  const startCameraPrompt = document.getElementById("startCameraPrompt")
  const processingIndicator = document.getElementById("processingIndicator")

  let stream = null

  // Start camera
  const startCamera = async () => {
    try {
      // Hide error message if visible
      cameraError.classList.add("hidden")
      startCameraPrompt.classList.add("hidden")

      // Get user media
      stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: "user" },
        audio: false,
      })

      // Set video source and show video
      video.srcObject = stream
      video.classList.remove("hidden")

      // Show capture button
      captureBtn.classList.remove("hidden")
    } catch (error) {
      console.error("Error accessing camera:", error)

      // Show error message
      cameraError.classList.remove("hidden")
      video.classList.add("hidden")
    }
  }

  // Stop camera
  const stopCamera = () => {
    if (stream) {
      stream.getTracks().forEach((track) => track.stop())
      stream = null
    }

    if (video.srcObject) {
      video.srcObject = null
    }
  }

  // Capture image
  const captureImage = () => {
    // Set canvas dimensions to match video
    canvas.width = video.videoWidth
    canvas.height = video.videoHeight

    // Draw video frame to canvas
    const ctx = canvas.getContext("2d")
    ctx.drawImage(video, 0, 0, canvas.width, canvas.height)

    // Convert canvas to data URL
    const imageDataUrl = canvas.toDataURL("image/png")

    // Display captured image
    capturedImage.src = imageDataUrl
    capturedImage.classList.remove("hidden")
    video.classList.add("hidden")

    // Update buttons
    captureBtn.classList.add("hidden")
    retakeBtn.classList.remove("hidden")
    analyzeBtn.classList.remove("hidden")

    // Stop camera
    stopCamera()
  }

  // Reset camera
  const resetCamera = () => {
    // Hide captured image
    capturedImage.classList.add("hidden")

    // Hide buttons
    retakeBtn.classList.add("hidden")
    analyzeBtn.classList.add("hidden")

    // Start camera again
    startCamera()
  }

  // Process image and navigate to results
  const processAndNavigate = async () => {
    // Show processing indicator
    analyzeBtn.classList.add("hidden")
    retakeBtn.classList.add("hidden")
    processingIndicator.classList.remove("hidden")

    try {
      // Simulate processing delay
      await new Promise((resolve) => setTimeout(resolve, 2000))

      // Generate random results
      const results = generateResults()

      // Store results in localStorage
      localStorage.setItem("glucovisionResults", JSON.stringify(results))

      // Navigate to results page
      window.location.href = "results.html"
    } catch (error) {
      console.error("Error processing image:", error)

      // Hide processing indicator and show buttons again
      processingIndicator.classList.add("hidden")
      analyzeBtn.classList.remove("hidden")
      retakeBtn.classList.remove("hidden")
    }
  }

  // Generate random results (simulated AI analysis)
  const generateResults = () => {
    // Generate random values
    const randomRiskScore = Math.floor(Math.random() * 10) + 1
    const randomGlucose = Math.floor(Math.random() * 60) + 90 // 90-150 range
    const randomConfidence = Math.floor(Math.random() * 20) + 80 // 80-100 range

    // Determine risk level based on score
    let riskLevel
    if (randomRiskScore <= 3) {
      riskLevel = "low"
    } else if (randomRiskScore <= 7) {
      riskLevel = "medium"
    } else {
      riskLevel = "high"
    }

    // Generate findings based on risk level
    const findings = generateFindings(riskLevel)

    // Generate recommendations based on risk level
    const recommendations = generateRecommendations(riskLevel)

    // Return simulated results
    return {
      riskLevel,
      riskScore: randomRiskScore,
      glucoseEstimation: randomGlucose,
      confidence: randomConfidence,
      findings,
      recommendations,
    }
  }

  // Generate findings based on risk level
  const generateFindings = (riskLevel) => {
    const lowRiskFindings = [
      "No visible microaneurysms detected in the retina",
      "Blood vessel structure appears normal",
      "No signs of retinal hemorrhages",
      "Optic disc and macula appear healthy",
    ]

    const mediumRiskFindings = [
      "Few microaneurysms detected in the peripheral retina",
      "Mild changes in blood vessel structure observed",
      "Early signs of retinal thickening may be present",
      "Possible early-stage diabetic retinopathy",
    ]

    const highRiskFindings = [
      "Multiple microaneurysms detected across the retina",
      "Significant changes in blood vessel structure observed",
      "Evidence of retinal hemorrhages present",
      "Signs of macular edema detected",
      "Advanced diabetic retinopathy indicators present",
    ]

    switch (riskLevel) {
      case "low":
        return lowRiskFindings
      case "medium":
        return mediumRiskFindings
      case "high":
        return highRiskFindings
      default:
        return lowRiskFindings
    }
  }

  // Generate recommendations based on risk level
  const generateRecommendations = (riskLevel) => {
    const lowRiskRecommendations = [
      "Continue regular annual eye examinations",
      "Maintain healthy blood glucose levels through diet and exercise",
      "Follow a balanced diet rich in antioxidants and omega-3 fatty acids",
      "Stay physically active with at least 150 minutes of moderate exercise weekly",
    ]

    const mediumRiskRecommendations = [
      "Schedule a follow-up examination with an ophthalmologist within 3-6 months",
      "Monitor blood glucose levels more frequently",
      "Consider consultation with an endocrinologist to optimize diabetes management",
      "Increase intake of foods rich in lutein and zeaxanthin for eye health",
      "Maintain a consistent exercise routine and reduce stress",
    ]

    const highRiskRecommendations = [
      "Consult with an ophthalmologist specializing in diabetic eye care within 30 days",
      "Strict blood glucose monitoring and management is essential",
      "Discuss potential treatment options with your healthcare provider",
      "Consider more frequent eye examinations (every 3-4 months)",
      "Implement comprehensive lifestyle changes including diet, exercise, and stress management",
    ]

    switch (riskLevel) {
      case "low":
        return lowRiskRecommendations
      case "medium":
        return mediumRiskRecommendations
      case "high":
        return highRiskRecommendations
      default:
        return lowRiskRecommendations
    }
  }

  // Event listeners
  if (startCameraBtn) {
    startCameraBtn.addEventListener("click", startCamera)
  }

  if (tryAgainBtn) {
    tryAgainBtn.addEventListener("click", startCamera)
  }

  if (captureBtn) {
    captureBtn.addEventListener("click", captureImage)
  }

  if (retakeBtn) {
    retakeBtn.addEventListener("click", resetCamera)
  }

  if (analyzeBtn) {
    analyzeBtn.addEventListener("click", processAndNavigate)
  }
})
