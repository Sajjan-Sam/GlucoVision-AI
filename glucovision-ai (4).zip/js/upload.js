document.addEventListener("DOMContentLoaded", () => {
  // Elements
  const dropZone = document.getElementById("dropZone")
  const uploadContent = document.getElementById("uploadContent")
  const previewContainer = document.getElementById("previewContainer")
  const previewImage = document.getElementById("previewImage")
  const fileInput = document.getElementById("fileInput")
  const browseBtn = document.getElementById("browseBtn")
  const removeImageBtn = document.getElementById("removeImageBtn")
  const uploadDifferentBtn = document.getElementById("uploadDifferentBtn")
  const analyzeUploadBtn = document.getElementById("analyzeUploadBtn")
  const uploadProcessingIndicator = document.getElementById("uploadProcessingIndicator")

  // Handle file upload
  const handleFileUpload = (file) => {
    if (!file) return

    // Check if file is an image
    if (!file.type.startsWith("image/")) {
      alert("Please upload an image file.")
      return
    }

    // Read file as data URL
    const reader = new FileReader()
    reader.onload = (e) => {
      if (e.target?.result) {
        // Display uploaded image
        previewImage.src = e.target.result
        uploadContent.classList.add("hidden")
        previewContainer.classList.remove("hidden")

        // Show action buttons
        uploadDifferentBtn.classList.remove("hidden")
        analyzeUploadBtn.classList.remove("hidden")
      }
    }
    reader.readAsDataURL(file)
  }

  // Handle file input change
  const handleFileInputChange = (e) => {
    if (e.target.files && e.target.files[0]) {
      handleFileUpload(e.target.files[0])
    }
  }

  // Handle drag events
  const handleDrag = (e) => {
    e.preventDefault()
    e.stopPropagation()

    if (e.type === "dragenter" || e.type === "dragover") {
      dropZone.classList.add("drag-active")
    } else if (e.type === "dragleave") {
      dropZone.classList.remove("drag-active")
    }
  }

  // Handle drop event
  const handleDrop = (e) => {
    e.preventDefault()
    e.stopPropagation()
    dropZone.classList.remove("drag-active")

    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFileUpload(e.dataTransfer.files[0])
    }
  }

  // Reset upload
  const resetUpload = () => {
    previewContainer.classList.add("hidden")
    uploadContent.classList.remove("hidden")
    uploadDifferentBtn.classList.add("hidden")
    analyzeUploadBtn.classList.add("hidden")

    if (fileInput) {
      fileInput.value = ""
    }
  }

  // Process image and navigate to results
  const processAndNavigate = async () => {
    // Show processing indicator
    analyzeUploadBtn.classList.add("hidden")
    uploadDifferentBtn.classList.add("hidden")
    uploadProcessingIndicator.classList.remove("hidden")

    try {
      // Simulate processing delay
      await new Promise((resolve) => setTimeout(resolve, 2000))

      // Generate random results
      const results = generateResults()

      // Store results in localStorage
      localStorage.setItem("glucovisionResults", JSON.stringify(results))

      // Navigate to results page
      window.location.href = "results.html"
    } catch (error) {
      console.error("Error processing image:", error)

      // Hide processing indicator and show buttons again
      uploadProcessingIndicator.classList.add("hidden")
      analyzeUploadBtn.classList.remove("hidden")
      uploadDifferentBtn.classList.remove("hidden")
    }
  }

  // Generate random results (simulated AI analysis)
  const generateResults = () => {
    // Generate random values
    const randomRiskScore = Math.floor(Math.random() * 10) + 1
    const randomGlucose = Math.floor(Math.random() * 60) + 90 // 90-150 range
    const randomConfidence = Math.floor(Math.random() * 20) + 80 // 80-100 range

    // Determine risk level based on score
    let riskLevel
    if (randomRiskScore <= 3) {
      riskLevel = "low"
    } else if (randomRiskScore <= 7) {
      riskLevel = "medium"
    } else {
      riskLevel = "high"
    }

    // Generate findings based on risk level
    const findings = generateFindings(riskLevel)

    // Generate recommendations based on risk level
    const recommendations = generateRecommendations(riskLevel)

    // Return simulated results
    return {
      riskLevel,
      riskScore: randomRiskScore,
      glucoseEstimation: randomGlucose,
      confidence: randomConfidence,
      findings,
      recommendations,
    }
  }

  // Generate findings based on risk level
  const generateFindings = (riskLevel) => {
    const lowRiskFindings = [
      "No visible microaneurysms detected in the retina",
      "Blood vessel structure appears normal",
      "No signs of retinal hemorrhages",
      "Optic disc and macula appear healthy",
    ]

    const mediumRiskFindings = [
      "Few microaneurysms detected in the peripheral retina",
      "Mild changes in blood vessel structure observed",
      "Early signs of retinal thickening may be present",
      "Possible early-stage diabetic retinopathy",
    ]

    const highRiskFindings = [
      "Multiple microaneurysms detected across the retina",
      "Significant changes in blood vessel structure observed",
      "Evidence of retinal hemorrhages present",
      "Signs of macular edema detected",
      "Advanced diabetic retinopathy indicators present",
    ]

    switch (riskLevel) {
      case "low":
        return lowRiskFindings
      case "medium":
        return mediumRiskFindings
      case "high":
        return highRiskFindings
      default:
        return lowRiskFindings
    }
  }

  // Generate recommendations based on risk level
  const generateRecommendations = (riskLevel) => {
    const lowRiskRecommendations = [
      "Continue regular annual eye examinations",
      "Maintain healthy blood glucose levels through diet and exercise",
      "Follow a balanced diet rich in antioxidants and omega-3 fatty acids",
      "Stay physically active with at least 150 minutes of moderate exercise weekly",
    ]

    const mediumRiskRecommendations = [
      "Schedule a follow-up examination with an ophthalmologist within 3-6 months",
      "Monitor blood glucose levels more frequently",
      "Consider consultation with an endocrinologist to optimize diabetes management",
      "Increase intake of foods rich in lutein and zeaxanthin for eye health",
      "Maintain a consistent exercise routine and reduce stress",
    ]

    const highRiskRecommendations = [
      "Consult with an ophthalmologist specializing in diabetic eye care within 30 days",
      "Strict blood glucose monitoring and management is essential",
      "Discuss potential treatment options with your healthcare provider",
      "Consider more frequent eye examinations (every 3-4 months)",
      "Implement comprehensive lifestyle changes including diet, exercise, and stress management",
    ]

    switch (riskLevel) {
      case "low":
        return lowRiskRecommendations
      case "medium":
        return mediumRiskRecommendations
      case "high":
        return highRiskRecommendations
      default:
        return lowRiskRecommendations
    }
  }

  // Event listeners
  if (fileInput) {
    fileInput.addEventListener("change", handleFileInputChange)
  }

  if (browseBtn) {
    browseBtn.addEventListener("click", () => {
      fileInput.click()
    })
  }

  if (dropZone) {
    ;["dragenter", "dragover", "dragleave", "drop"].forEach((eventName) => {
      dropZone.addEventListener(eventName, handleDrag)
    })

    dropZone.addEventListener("drop", handleDrop)
  }

  if (removeImageBtn) {
    removeImageBtn.addEventListener("click", resetUpload)
  }

  if (uploadDifferentBtn) {
    uploadDifferentBtn.addEventListener("click", resetUpload)
  }

  if (analyzeUploadBtn) {
    analyzeUploadBtn.addEventListener("click", processAndNavigate)
  }
})
