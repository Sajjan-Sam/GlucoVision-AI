import { Activity, BarChart3, Percent } from "lucide-react"

interface HolographicDataCardProps {
  title: string
  value: string
  subtitle: string
  icon: "chart" | "activity" | "percent"
  color: "cyan" | "gold"
}

export function HolographicDataCard({ title, value, subtitle, icon, color }: HolographicDataCardProps) {
  const getIcon = () => {
    switch (icon) {
      case "chart":
        return <BarChart3 className={`h-6 w-6 text-${color}-DEFAULT`} />
      case "activity":
        return <Activity className={`h-6 w-6 text-${color}-DEFAULT`} />
      case "percent":
        return <Percent className={`h-6 w-6 text-${color}-DEFAULT`} />
      default:
        return <BarChart3 className={`h-6 w-6 text-${color}-DEFAULT`} />
    }
  }

  return (
    <div className={`holographic-card rounded-xl p-6 animate-float border border-${color}-DEFAULT/30`}>
      <div className="flex justify-between items-start mb-4">
        <h3 className="text-white font-semibold">{title}</h3>
        <div className={`bg-${color}-DEFAULT/20 rounded-full p-2`}>{getIcon()}</div>
      </div>

      <div className="mt-2">
        <p className={`text-3xl font-bold text-${color}-DEFAULT mb-1`}>{value}</p>
        <p className="text-gray-400 text-sm">{subtitle}</p>
      </div>
    </div>
  )
}
