import { Card } from "@/components/ui/card"
import { Salad, HeartPulse, Moon, Dumbbell, AlertTriangle } from "lucide-react"

interface HealthTipsProps {
  riskLevel: "low" | "medium" | "high"
}

export function HealthTips({ riskLevel }: HealthTipsProps) {
  return (
    <Card className="holographic-card p-8">
      <h3 className="text-2xl font-bold text-white glow-text mb-6 text-center">Personalized Health Tips</h3>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-navy-light/50 rounded-lg p-4 border border-cyan-DEFAULT/20">
          <div className="flex items-center mb-3">
            <div className="bg-cyan-dark/30 rounded-full p-2 mr-3">
              <Salad className="h-5 w-5 text-cyan-DEFAULT" />
            </div>
            <h4 className="text-white font-semibold">Diet Recommendations</h4>
          </div>
          <ul className="space-y-2 text-gray-300 text-sm">
            <li>• Focus on low-glycemic index foods to maintain stable blood sugar</li>
            <li>• Increase fiber intake through vegetables, fruits, and whole grains</li>
            <li>• Limit processed foods and added sugars</li>
            {riskLevel !== "low" && <li>• Consider consulting with a dietitian for a personalized meal plan</li>}
          </ul>
        </div>

        <div className="bg-navy-light/50 rounded-lg p-4 border border-cyan-DEFAULT/20">
          <div className="flex items-center mb-3">
            <div className="bg-cyan-dark/30 rounded-full p-2 mr-3">
              <Dumbbell className="h-5 w-5 text-cyan-DEFAULT" />
            </div>
            <h4 className="text-white font-semibold">Exercise Guidelines</h4>
          </div>
          <ul className="space-y-2 text-gray-300 text-sm">
            <li>• Aim for at least 150 minutes of moderate activity per week</li>
            <li>• Include both aerobic exercise and strength training</li>
            <li>• Start slowly and gradually increase intensity</li>
            {riskLevel === "high" && <li>• Consult with your doctor before starting a new exercise program</li>}
          </ul>
        </div>

        <div className="bg-navy-light/50 rounded-lg p-4 border border-cyan-DEFAULT/20">
          <div className="flex items-center mb-3">
            <div className="bg-cyan-dark/30 rounded-full p-2 mr-3">
              <HeartPulse className="h-5 w-5 text-cyan-DEFAULT" />
            </div>
            <h4 className="text-white font-semibold">Health Monitoring</h4>
          </div>
          <ul className="space-y-2 text-gray-300 text-sm">
            {riskLevel === "low" ? (
              <>
                <li>• Schedule regular eye exams annually</li>
                <li>• Monitor blood pressure and cholesterol levels</li>
              </>
            ) : riskLevel === "medium" ? (
              <>
                <li>• Schedule eye exams every 6 months</li>
                <li>• Consider regular blood glucose monitoring</li>
                <li>• Track blood pressure weekly</li>
              </>
            ) : (
              <>
                <li>• Consult with an ophthalmologist promptly</li>
                <li>• Monitor blood glucose levels daily</li>
                <li>• Schedule comprehensive diabetic check-ups</li>
              </>
            )}
          </ul>
        </div>

        <div className="bg-navy-light/50 rounded-lg p-4 border border-cyan-DEFAULT/20">
          <div className="flex items-center mb-3">
            <div className="bg-cyan-dark/30 rounded-full p-2 mr-3">
              <Moon className="h-5 w-5 text-cyan-DEFAULT" />
            </div>
            <h4 className="text-white font-semibold">Lifestyle Adjustments</h4>
          </div>
          <ul className="space-y-2 text-gray-300 text-sm">
            <li>• Prioritize 7-8 hours of quality sleep each night</li>
            <li>• Practice stress management techniques</li>
            <li>• Stay hydrated with at least 8 glasses of water daily</li>
            {(riskLevel === "medium" || riskLevel === "high") && <li>• Avoid smoking and limit alcohol consumption</li>}
          </ul>
        </div>
      </div>

      {riskLevel !== "low" && (
        <div className="mt-6 bg-navy-light/50 rounded-lg p-4 border border-gold-DEFAULT/20">
          <div className="flex items-start">
            <div className="bg-gold-DEFAULT/20 rounded-full p-2 mr-3 mt-1">
              <AlertTriangle className="h-5 w-5 text-gold-DEFAULT" />
            </div>
            <div>
              <h4 className="text-white font-semibold mb-1">Important Note</h4>
              <p className="text-gray-300 text-sm">
                {riskLevel === "medium"
                  ? "Based on your results, we recommend scheduling an appointment with an eye care specialist within the next 3 months for a comprehensive evaluation."
                  : "Your results indicate a higher risk level. We strongly recommend consulting with an ophthalmologist within the next 30 days for a thorough examination and appropriate treatment plan."}
              </p>
            </div>
          </div>
        </div>
      )}
    </Card>
  )
}
