import Link from "next/link"
import { Eye } from "lucide-react"

export default function Footer() {
  return (
    <footer className="bg-navy-dark border-t border-cyan-DEFAULT/20 py-8">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
          <div>
            <Link href="/" className="flex items-center mb-4">
              <Eye className="h-6 w-6 text-cyan-DEFAULT mr-2" />
              <span className="text-lg font-bold text-white">GlucoVision AI</span>
            </Link>
            <p className="text-gray-400 text-sm">Redefining Diabetes Care Through AI Vision</p>
          </div>

          <div>
            <h3 className="text-white font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/" className="text-gray-400 hover:text-cyan-light text-sm transition-colors">
                  Home
                </Link>
              </li>
              <li>
                <Link href="/scan" className="text-gray-400 hover:text-cyan-light text-sm transition-colors">
                  Scan My Eye
                </Link>
              </li>
              <li>
                <Link href="/upload" className="text-gray-400 hover:text-cyan-light text-sm transition-colors">
                  Upload Image
                </Link>
              </li>
              <li>
                <Link href="/about" className="text-gray-400 hover:text-cyan-light text-sm transition-colors">
                  About Us
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-white font-semibold mb-4">Resources</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/faq" className="text-gray-400 hover:text-cyan-light text-sm transition-colors">
                  FAQ
                </Link>
              </li>
              <li>
                <Link href="/privacy" className="text-gray-400 hover:text-cyan-light text-sm transition-colors">
                  Privacy Policy
                </Link>
              </li>
              <li>
                <Link href="/terms" className="text-gray-400 hover:text-cyan-light text-sm transition-colors">
                  Terms of Service
                </Link>
              </li>
              <li>
                <Link href="/contact" className="text-gray-400 hover:text-cyan-light text-sm transition-colors">
                  Contact Us
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-white font-semibold mb-4">Connect</h3>
            <ul className="space-y-2">
              <li>
                <a href="#" className="text-gray-400 hover:text-cyan-light text-sm transition-colors">
                  Twitter
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-400 hover:text-cyan-light text-sm transition-colors">
                  LinkedIn
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-400 hover:text-cyan-light text-sm transition-colors">
                  Facebook
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-400 hover:text-cyan-light text-sm transition-colors">
                  Instagram
                </a>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-cyan-DEFAULT/10 pt-6 text-center">
          <p className="text-gray-500 text-sm">© {new Date().getFullYear()} GlucoVision AI. All rights reserved.</p>
          <p className="text-gray-500 text-xs mt-2">
            <strong>Disclaimer:</strong> This is an experimental AI tool. Not a replacement for medical advice. Always
            consult with healthcare professionals for medical diagnoses and treatment.
          </p>
        </div>
      </div>
    </footer>
  )
}
