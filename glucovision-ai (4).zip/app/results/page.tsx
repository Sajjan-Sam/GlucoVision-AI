"use client"

import { useState, useEffect } from "react"
import { useSearchParams } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { AlertTriangle, CheckCircle, Info, Volume2, VolumeX, Download, Share2, ArrowLeft } from "lucide-react"
import Navbar from "@/components/navbar"
import Footer from "@/components/footer"
import Link from "next/link"
import { HealthTips } from "@/components/health-tips"
import { RiskLevelBadge } from "@/components/risk-level-badge"
import { HolographicDataCard } from "@/components/holographic-data-card"

// Types
interface ResultData {
  riskLevel: "low" | "medium" | "high"
  riskScore: number
  glucoseEstimation: number
  confidence: number
  findings: string[]
  recommendations: string[]
}

export default function ResultsPage() {
  const searchParams = useSearchParams()
  const [resultData, setResultData] = useState<ResultData | null>(null)
  const [isVoiceActive, setIsVoiceActive] = useState(false)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    // Get data from URL params
    const dataParam = searchParams.get("data")

    if (dataParam) {
      try {
        const parsedData = JSON.parse(decodeURIComponent(dataParam))
        setResultData(parsedData)
      } catch (error) {
        console.error("Error parsing result data:", error)
      }
    }

    // Simulate loading
    const timer = setTimeout(() => {
      setIsLoading(false)
    }, 1500)

    return () => clearTimeout(timer)
  }, [searchParams])

  // Toggle voice narration
  const toggleVoice = () => {
    if (isVoiceActive) {
      // Stop voice
      window.speechSynthesis.cancel()
      setIsVoiceActive(false)
    } else {
      // Start voice narration
      if (resultData) {
        const speech = new SpeechSynthesisUtterance()
        speech.text = `
          Your GlucoVision AI analysis results show a ${resultData.riskLevel} risk level for diabetic retinopathy.
          Your estimated glucose level is approximately ${resultData.glucoseEstimation} mg/dL.
          Key findings include: ${resultData.findings.join(", ")}.
          Our recommendations are: ${resultData.recommendations.join(", ")}.
          Please remember this is an experimental tool and not a replacement for professional medical advice.
        `
        speech.rate = 0.9
        speech.pitch = 1
        speech.volume = 1

        window.speechSynthesis.speak(speech)
        setIsVoiceActive(true)

        speech.onend = () => {
          setIsVoiceActive(false)
        }
      }
    }
  }

  // Download results as PDF (simulated)
  const downloadResults = () => {
    alert("This would download your results as a PDF in a real application.")
  }

  // Share results (simulated)
  const shareResults = () => {
    alert("This would share your results in a real application.")
  }

  if (isLoading) {
    return (
      <main className="min-h-screen futuristic-gradient grid-pattern">
        <Navbar />

        <div className="container mx-auto px-4 py-24 flex items-center justify-center">
          <div className="text-center">
            <div className="inline-block mb-6">
              <div className="h-16 w-16 border-4 border-cyan-DEFAULT border-t-transparent rounded-full animate-spin mx-auto"></div>
            </div>
            <h2 className="text-2xl font-bold text-white glow-text mb-4">Analyzing Your Results</h2>
            <p className="text-gray-300">Our AI is processing your retinal scan data...</p>
          </div>
        </div>

        <Footer />
      </main>
    )
  }

  if (!resultData) {
    return (
      <main className="min-h-screen futuristic-gradient grid-pattern">
        <Navbar />

        <div className="container mx-auto px-4 py-24 flex items-center justify-center">
          <Card className="holographic-card p-8 max-w-lg w-full text-center">
            <AlertTriangle className="h-12 w-12 text-gold-DEFAULT mx-auto mb-4" />
            <h2 className="text-2xl font-bold text-white glow-text mb-4">No Result Data Found</h2>
            <p className="text-gray-300 mb-6">
              We couldn't find any analysis results. Please try scanning or uploading an image again.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link href="/scan">
                <Button className="bg-cyan-DEFAULT hover:bg-cyan-dark text-white font-bold w-full sm:w-auto">
                  Try Scanning
                </Button>
              </Link>
              <Link href="/upload">
                <Button
                  variant="outline"
                  className="border-cyan-DEFAULT text-cyan-DEFAULT hover:text-cyan-light hover:border-cyan-light w-full sm:w-auto"
                >
                  Upload Image
                </Button>
              </Link>
            </div>
          </Card>
        </div>

        <Footer />
      </main>
    )
  }

  return (
    <main className="min-h-screen futuristic-gradient grid-pattern">
      <Navbar />

      <div className="container mx-auto px-4 py-12">
        <div className="max-w-4xl mx-auto">
          <div className="flex justify-between items-center mb-8">
            <Link href="/" className="text-cyan-light hover:text-cyan-DEFAULT flex items-center">
              <ArrowLeft className="h-5 w-5 mr-2" />
              <span>Back to Home</span>
            </Link>

            <div className="flex items-center space-x-4">
              <Button
                variant="outline"
                size="icon"
                className="border-cyan-DEFAULT/50 text-cyan-DEFAULT hover:text-cyan-light hover:border-cyan-light rounded-full"
                onClick={toggleVoice}
              >
                {isVoiceActive ? <VolumeX className="h-5 w-5" /> : <Volume2 className="h-5 w-5" />}
              </Button>

              <Button
                variant="outline"
                size="icon"
                className="border-cyan-DEFAULT/50 text-cyan-DEFAULT hover:text-cyan-light hover:border-cyan-light rounded-full"
                onClick={downloadResults}
              >
                <Download className="h-5 w-5" />
              </Button>

              <Button
                variant="outline"
                size="icon"
                className="border-cyan-DEFAULT/50 text-cyan-DEFAULT hover:text-cyan-light hover:border-cyan-light rounded-full"
                onClick={shareResults}
              >
                <Share2 className="h-5 w-5" />
              </Button>
            </div>
          </div>

          <h1 className="text-3xl md:text-4xl font-bold text-white glow-text text-center mb-2">Your Health Analysis</h1>

          <p className="text-cyan-light text-center glow-text text-xl mb-12">
            GlucoVision AI – Redefining Diabetes Care Through AI Vision
          </p>

          {/* Main Results Card */}
          <Card className="holographic-card p-8 mb-8">
            <div className="flex flex-col md:flex-row items-center md:items-start gap-8 mb-8">
              <div className="w-full md:w-1/3 flex flex-col items-center">
                <RiskLevelBadge level={resultData.riskLevel} />

                <div className="mt-6 text-center">
                  <p className="text-gray-400 mb-1">Confidence Level</p>
                  <p className="text-white text-2xl font-bold">{resultData.confidence}%</p>
                </div>
              </div>

              <div className="w-full md:w-2/3">
                <h3 className="text-xl font-bold text-white mb-4">Key Findings</h3>

                <ul className="space-y-3 mb-6">
                  {resultData.findings.map((finding, index) => (
                    <li key={index} className="flex items-start">
                      <Info className="h-5 w-5 text-cyan-DEFAULT mr-2 mt-0.5 flex-shrink-0" />
                      <span className="text-gray-300">{finding}</span>
                    </li>
                  ))}
                </ul>

                <div className="bg-navy-light/50 rounded-lg p-4 border border-cyan-DEFAULT/20">
                  <div className="flex items-center mb-2">
                    <CheckCircle className="h-5 w-5 text-cyan-DEFAULT mr-2" />
                    <h4 className="text-white font-semibold">Estimated Glucose Level</h4>
                  </div>
                  <p className="text-gray-300">
                    Based on retinal analysis, your estimated glucose level is approximately:
                  </p>
                  <p className="text-2xl font-bold text-white mt-2">
                    {resultData.glucoseEstimation} <span className="text-sm text-gray-400">mg/dL</span>
                  </p>
                  <p className="text-xs text-gray-400 mt-1">
                    Note: This is an experimental estimation and should not replace blood glucose testing.
                  </p>
                </div>
              </div>
            </div>

            <div className="border-t border-cyan-DEFAULT/20 pt-6">
              <h3 className="text-xl font-bold text-white mb-4">Recommendations</h3>

              <ul className="space-y-3">
                {resultData.recommendations.map((recommendation, index) => (
                  <li key={index} className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-cyan-DEFAULT mr-2 mt-0.5 flex-shrink-0" />
                    <span className="text-gray-300">{recommendation}</span>
                  </li>
                ))}
              </ul>
            </div>
          </Card>

          {/* Holographic Data Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
            <HolographicDataCard
              title="Risk Score"
              value={resultData.riskScore.toString()}
              subtitle="Out of 10"
              icon="chart"
              color="cyan"
            />

            <HolographicDataCard
              title="Glucose Level"
              value={`${resultData.glucoseEstimation}`}
              subtitle="mg/dL"
              icon="activity"
              color="gold"
            />

            <HolographicDataCard
              title="Confidence"
              value={`${resultData.confidence}%`}
              subtitle="AI Certainty"
              icon="percent"
              color="cyan"
            />
          </div>

          {/* Health Tips Section */}
          <HealthTips riskLevel={resultData.riskLevel} />

          <div className="text-center text-gray-400 text-sm mt-12">
            <p className="mb-2">
              Your privacy is important to us. Results are not stored permanently unless you create an account.
            </p>
            <p>
              <strong>Disclaimer:</strong> This is an experimental AI tool. Not a replacement for medical advice. Always
              consult with healthcare professionals for medical diagnoses and treatment.
            </p>
          </div>
        </div>
      </div>

      <Footer />
    </main>
  )
}
