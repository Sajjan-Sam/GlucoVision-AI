import Navbar from "@/components/navbar"
import Footer from "@/components/footer"
import { Card } from "@/components/ui/card"
import { Brain, Shield, Globe } from "lucide-react"

export default function AboutPage() {
  return (
    <main className="min-h-screen futuristic-gradient grid-pattern">
      <Navbar />

      <div className="container mx-auto px-4 py-12">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-3xl md:text-4xl font-bold text-white glow-text text-center mb-8">About GlucoVision AI</h1>

          <p className="text-xl text-cyan-light text-center glow-text mb-12">
            Redefining Diabetes Care Through AI Vision
          </p>

          <Card className="holographic-card p-8 mb-12">
            <h2 className="text-2xl font-bold text-white mb-6">Our Mission</h2>

            <p className="text-gray-300 mb-4">
              GlucoVision AI was founded with a singular mission: to make early detection of diabetic retinopathy
              accessible to everyone, everywhere. By leveraging cutting-edge artificial intelligence and computer vision
              technology, we aim to revolutionize how diabetes-related eye conditions are detected and monitored.
            </p>

            <p className="text-gray-300 mb-4">
              Diabetic retinopathy is the leading cause of blindness among working-age adults, yet early detection can
              prevent up to 95% of severe vision loss cases. Unfortunately, many people lack access to regular eye
              screenings due to cost, location, or awareness.
            </p>

            <p className="text-gray-300">
              Our technology enables anyone with a smartphone or webcam to perform a preliminary screening, encouraging
              earlier medical intervention and potentially saving the vision of millions worldwide.
            </p>
          </Card>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
            <Card className="holographic-card p-6">
              <div className="flex items-start mb-4">
                <div className="bg-cyan-dark/20 rounded-full p-3 mr-4">
                  <Brain className="h-6 w-6 text-cyan-DEFAULT" />
                </div>
                <div>
                  <h3 className="text-xl font-bold text-white mb-2">Our Technology</h3>
                  <p className="text-gray-300">
                    GlucoVision AI utilizes deep convolutional neural networks trained on thousands of retinal images to
                    detect subtle changes associated with diabetic retinopathy. Our algorithms can identify
                    microaneurysms, hemorrhages, exudates, and other pathological markers with high accuracy.
                  </p>
                </div>
              </div>
            </Card>

            <Card className="holographic-card p-6">
              <div className="flex items-start mb-4">
                <div className="bg-cyan-dark/20 rounded-full p-3 mr-4">
                  <Shield className="h-6 w-6 text-cyan-DEFAULT" />
                </div>
                <div>
                  <h3 className="text-xl font-bold text-white mb-2">Privacy & Security</h3>
                  <p className="text-gray-300">
                    We prioritize your privacy and data security. All images are processed using state-of-the-art
                    encryption, and we do not permanently store retinal scans unless explicitly authorized. Our systems
                    comply with healthcare data protection standards to ensure your information remains confidential.
                  </p>
                </div>
              </div>
            </Card>
          </div>

          <Card className="holographic-card p-8 mb-12">
            <h2 className="text-2xl font-bold text-white mb-6">The Science Behind GlucoVision</h2>

            <p className="text-gray-300 mb-4">
              The relationship between retinal health and diabetes has been well-established in medical literature. The
              retina contains a rich network of blood vessels that can reveal early signs of vascular damage caused by
              elevated blood glucose levels.
            </p>

            <p className="text-gray-300 mb-4">
              Our AI models have been trained to recognize these subtle changes, which often appear before other
              symptoms of diabetes become apparent. By analyzing the pattern, size, and distribution of blood vessels,
              as well as identifying abnormalities like microaneurysms and exudates, our technology can assess the
              likelihood of diabetic retinopathy.
            </p>

            <p className="text-gray-300 mb-4">
              Recent research has also shown correlations between retinal vascular patterns and blood glucose levels,
              allowing for non-invasive glucose estimation. While this technology is still evolving, it offers promising
              potential for monitoring diabetes without traditional blood tests.
            </p>

            <div className="bg-navy-light/50 rounded-lg p-4 border border-cyan-DEFAULT/20 mt-6">
              <p className="text-gray-300 text-sm">
                <strong className="text-white">Note:</strong> While our technology shows promising results in research
                settings, GlucoVision AI is designed as a screening tool, not a replacement for professional medical
                diagnosis. Always consult healthcare professionals for definitive diagnoses and treatment plans.
              </p>
            </div>
          </Card>

          <Card className="holographic-card p-8 mb-12">
            <div className="flex items-start mb-6">
              <div className="bg-cyan-dark/20 rounded-full p-3 mr-4">
                <Globe className="h-6 w-6 text-cyan-DEFAULT" />
              </div>
              <div>
                <h2 className="text-2xl font-bold text-white mb-2">Global Impact</h2>
                <p className="text-gray-300">
                  Diabetes affects over 460 million people worldwide, with numbers projected to rise significantly in
                  the coming decades. By making early detection accessible through everyday technology, GlucoVision AI
                  aims to reduce the global burden of diabetic eye disease, particularly in underserved regions where
                  specialist care is limited.
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-center">
              <div className="bg-navy-light/50 rounded-lg p-4 border border-cyan-DEFAULT/20">
                <h3 className="text-cyan-DEFAULT text-4xl font-bold mb-2">463M</h3>
                <p className="text-gray-400 text-sm">People with diabetes worldwide</p>
              </div>

              <div className="bg-navy-light/50 rounded-lg p-4 border border-cyan-DEFAULT/20">
                <h3 className="text-cyan-DEFAULT text-4xl font-bold mb-2">1 in 3</h3>
                <p className="text-gray-400 text-sm">Diabetics develop retinopathy</p>
              </div>

              <div className="bg-navy-light/50 rounded-lg p-4 border border-cyan-DEFAULT/20">
                <h3 className="text-cyan-DEFAULT text-4xl font-bold mb-2">95%</h3>
                <p className="text-gray-400 text-sm">Of vision loss is preventable with early detection</p>
              </div>
            </div>
          </Card>

          <div className="text-center text-gray-400 text-sm">
            <p className="mb-2">
              GlucoVision AI is currently in beta testing phase. Our technology is continuously improving through
              machine learning and feedback from healthcare professionals.
            </p>
            <p>
              <strong>Disclaimer:</strong> This is an experimental AI tool. Not a replacement for medical advice. Always
              consult with healthcare professionals for medical diagnoses and treatment.
            </p>
          </div>
        </div>
      </div>

      <Footer />
    </main>
  )
}
