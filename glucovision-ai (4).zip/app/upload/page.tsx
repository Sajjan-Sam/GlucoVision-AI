"use client"

import type React from "react"

import { useState, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Upload, RefreshCw, ArrowRight, X } from "lucide-react"
import Navbar from "@/components/navbar"
import Footer from "@/components/footer"
import { useRouter } from "next/navigation"
import { processImage } from "@/lib/image-processor"

export default function UploadPage() {
  const router = useRouter()
  const fileInputRef = useRef<HTMLInputElement>(null)
  const [uploadedImage, setUploadedImage] = useState<string | null>(null)
  const [isProcessing, setIsProcessing] = useState(false)
  const [dragActive, setDragActive] = useState(false)

  // Handle file upload
  const handleFileUpload = (file: File) => {
    if (!file) return

    // Check if file is an image
    if (!file.type.startsWith("image/")) {
      alert("Please upload an image file.")
      return
    }

    // Read file as data URL
    const reader = new FileReader()
    reader.onload = (e) => {
      if (e.target?.result) {
        setUploadedImage(e.target.result as string)
      }
    }
    reader.readAsDataURL(file)
  }

  // Handle file input change
  const handleFileInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      handleFileUpload(e.target.files[0])
    }
  }

  // Handle drag events
  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()

    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true)
    } else if (e.type === "dragleave") {
      setDragActive(false)
    }
  }

  // Handle drop event
  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
    setDragActive(false)

    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFileUpload(e.dataTransfer.files[0])
    }
  }

  // Trigger file input click
  const triggerFileInput = () => {
    fileInputRef.current?.click()
  }

  // Reset uploaded image
  const resetUpload = () => {
    setUploadedImage(null)
    if (fileInputRef.current) {
      fileInputRef.current.value = ""
    }
  }

  // Process image and navigate to results
  const processAndNavigate = async () => {
    if (!uploadedImage) return

    setIsProcessing(true)

    try {
      // Process the image (simulated)
      const results = await processImage(uploadedImage)

      // Navigate to results page with the processed data
      router.push(`/results?data=${encodeURIComponent(JSON.stringify(results))}`)
    } catch (error) {
      console.error("Error processing image:", error)
      setIsProcessing(false)
    }
  }

  return (
    <main className="min-h-screen futuristic-gradient grid-pattern">
      <Navbar />

      <div className="container mx-auto px-4 py-12">
        <div className="max-w-3xl mx-auto">
          <h1 className="text-3xl md:text-4xl font-bold text-white glow-text text-center mb-8">Upload Retinal Image</h1>

          <p className="text-gray-300 text-center mb-12">
            Upload a clear, high-resolution image of your retina for analysis. For best results, use images taken by
            professional retinal cameras.
          </p>

          <Card className="holographic-card overflow-hidden mb-8">
            <div
              className={`aspect-video relative bg-navy-dark flex items-center justify-center
                ${dragActive ? "border-2 border-dashed border-cyan-light" : ""}
              `}
              onDragEnter={handleDrag}
              onDragLeave={handleDrag}
              onDragOver={handleDrag}
              onDrop={handleDrop}
            >
              {!uploadedImage ? (
                <div className="text-center p-8">
                  <Upload className="h-12 w-12 text-cyan-DEFAULT mx-auto mb-4" />
                  <h3 className="text-white text-lg font-semibold mb-2">Drag and drop your image here</h3>
                  <p className="text-gray-400 mb-6">or click to browse files</p>
                  <Button
                    onClick={triggerFileInput}
                    className="bg-cyan-DEFAULT hover:bg-cyan-dark text-white font-bold"
                  >
                    Browse Files
                  </Button>
                  <input
                    type="file"
                    ref={fileInputRef}
                    onChange={handleFileInputChange}
                    accept="image/*"
                    className="hidden"
                  />
                </div>
              ) : (
                <div className="relative w-full h-full">
                  <img
                    src={uploadedImage || "/placeholder.svg"}
                    alt="Uploaded retinal image"
                    className="w-full h-full object-contain"
                  />
                  <button
                    onClick={resetUpload}
                    className="absolute top-2 right-2 bg-navy-dark/80 text-white p-1 rounded-full"
                  >
                    <X className="h-5 w-5" />
                  </button>
                </div>
              )}
            </div>
          </Card>

          <div className="flex justify-center space-x-4 mb-12">
            {uploadedImage && (
              <>
                <Button
                  onClick={resetUpload}
                  variant="outline"
                  className="border-cyan-DEFAULT text-cyan-DEFAULT hover:text-cyan-light hover:border-cyan-light px-6 py-5 text-lg rounded-lg transition-all duration-300"
                >
                  <RefreshCw className="mr-2 h-5 w-5" />
                  Upload Different Image
                </Button>

                <Button
                  onClick={processAndNavigate}
                  disabled={isProcessing}
                  className="bg-cyan-DEFAULT hover:bg-cyan-dark text-white font-bold px-6 py-5 text-lg rounded-lg glow-cyan transition-all duration-300"
                >
                  {isProcessing ? (
                    <>
                      <RefreshCw className="mr-2 h-5 w-5 animate-spin" />
                      Processing...
                    </>
                  ) : (
                    <>
                      <ArrowRight className="mr-2 h-5 w-5" />
                      Analyze Image
                    </>
                  )}
                </Button>
              </>
            )}
          </div>

          <div className="text-center text-gray-400 text-sm">
            <p className="mb-2">
              Your privacy is important to us. Images are processed securely and not stored permanently.
            </p>
            <p>
              <strong>Disclaimer:</strong> This is an experimental AI tool. Not a replacement for medical advice.
            </p>
          </div>
        </div>
      </div>

      <Footer />
    </main>
  )
}
