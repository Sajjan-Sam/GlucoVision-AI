import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Sparkles, Eye, Upload, ArrowRight } from "lucide-react"
import Navbar from "@/components/navbar"
import Footer from "@/components/footer"

export default function Home() {
  return (
    <main className="min-h-screen futuristic-gradient grid-pattern">
      <Navbar />

      <div className="container mx-auto px-4 py-16 md:py-24">
        {/* Hero Section */}
        <div className="flex flex-col items-center text-center mb-16">
          <div className="relative mb-6">
            <h1 className="text-4xl md:text-6xl font-bold text-white glow-text mb-4">GlucoVision AI</h1>
            <div className="absolute -top-4 -right-4 text-cyan-light">
              <Sparkles className="w-8 h-8 animate-pulse" />
            </div>
          </div>

          <p className="text-xl md:text-2xl text-cyan-light mb-8 max-w-3xl glow-text">
            Redefining Diabetes Care Through AI Vision
          </p>

          <p className="text-gray-300 mb-12 max-w-2xl">
            Our cutting-edge AI technology analyzes retinal images to assess diabetic risk factors and provide
            personalized health insights, all in seconds.
          </p>

          <div className="flex flex-col sm:flex-row gap-4">
            <Link href="/scan">
              <Button className="bg-cyan-DEFAULT hover:bg-cyan-dark text-white font-bold px-8 py-6 text-lg rounded-lg glow-cyan transition-all duration-300 hover:scale-105">
                <Eye className="mr-2 h-5 w-5" />
                Scan My Eye
              </Button>
            </Link>
            <Link href="/upload">
              <Button
                variant="outline"
                className="border-cyan-DEFAULT text-cyan-DEFAULT hover:text-cyan-light hover:border-cyan-light px-8 py-6 text-lg rounded-lg transition-all duration-300 hover:scale-105"
              >
                <Upload className="mr-2 h-5 w-5" />
                Upload Image
              </Button>
            </Link>
          </div>
        </div>

        {/* Features Section */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
          <div className="holographic-card rounded-xl p-6 animate-float">
            <div className="bg-cyan-dark/20 rounded-full p-3 w-fit mb-4">
              <Eye className="h-8 w-8 text-cyan-DEFAULT" />
            </div>
            <h3 className="text-xl font-bold text-white mb-2">Retinal Analysis</h3>
            <p className="text-gray-300">
              Advanced computer vision algorithms analyze retinal patterns to detect early signs of diabetic
              retinopathy.
            </p>
          </div>

          <div className="holographic-card rounded-xl p-6 animate-float" style={{ animationDelay: "0.2s" }}>
            <div className="bg-cyan-dark/20 rounded-full p-3 w-fit mb-4">
              <Sparkles className="h-8 w-8 text-gold-DEFAULT" />
            </div>
            <h3 className="text-xl font-bold text-white mb-2">AI-Powered Insights</h3>
            <p className="text-gray-300">
              Get personalized health recommendations based on your scan results and risk assessment.
            </p>
          </div>

          <div className="holographic-card rounded-xl p-6 animate-float" style={{ animationDelay: "0.4s" }}>
            <div className="bg-cyan-dark/20 rounded-full p-3 w-fit mb-4">
              <ArrowRight className="h-8 w-8 text-cyan-light" />
            </div>
            <h3 className="text-xl font-bold text-white mb-2">Instant Results</h3>
            <p className="text-gray-300">
              Receive your health assessment in seconds with detailed explanations and next steps.
            </p>
          </div>
        </div>

        {/* How It Works Section */}
        <div className="mb-16">
          <h2 className="text-3xl font-bold text-white glow-text text-center mb-12">How It Works</h2>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <div className="text-center">
              <div className="bg-navy-light rounded-full h-16 w-16 flex items-center justify-center mx-auto mb-4 border border-cyan-DEFAULT/30">
                <span className="text-xl font-bold text-cyan-DEFAULT">1</span>
              </div>
              <h3 className="text-lg font-semibold text-white mb-2">Scan or Upload</h3>
              <p className="text-gray-400">Use your webcam or upload a retinal image</p>
            </div>

            <div className="text-center">
              <div className="bg-navy-light rounded-full h-16 w-16 flex items-center justify-center mx-auto mb-4 border border-cyan-DEFAULT/30">
                <span className="text-xl font-bold text-cyan-DEFAULT">2</span>
              </div>
              <h3 className="text-lg font-semibold text-white mb-2">AI Analysis</h3>
              <p className="text-gray-400">Our AI processes the image in seconds</p>
            </div>

            <div className="text-center">
              <div className="bg-navy-light rounded-full h-16 w-16 flex items-center justify-center mx-auto mb-4 border border-cyan-DEFAULT/30">
                <span className="text-xl font-bold text-cyan-DEFAULT">3</span>
              </div>
              <h3 className="text-lg font-semibold text-white mb-2">Risk Assessment</h3>
              <p className="text-gray-400">Get your diabetic risk evaluation</p>
            </div>

            <div className="text-center">
              <div className="bg-navy-light rounded-full h-16 w-16 flex items-center justify-center mx-auto mb-4 border border-cyan-DEFAULT/30">
                <span className="text-xl font-bold text-cyan-DEFAULT">4</span>
              </div>
              <h3 className="text-lg font-semibold text-white mb-2">Health Insights</h3>
              <p className="text-gray-400">Receive personalized health recommendations</p>
            </div>
          </div>
        </div>

        {/* CTA Section */}
        <div className="text-center mb-16">
          <h2 className="text-3xl font-bold text-white glow-text mb-6">Ready to Take Control of Your Health?</h2>
          <p className="text-gray-300 mb-8 max-w-2xl mx-auto">
            Early detection is key to managing diabetes. Get started with GlucoVision AI today.
          </p>
          <Link href="/scan">
            <Button className="bg-cyan-DEFAULT hover:bg-cyan-dark text-white font-bold px-8 py-6 text-lg rounded-lg glow-cyan transition-all duration-300 hover:scale-105">
              Start Your Scan Now
            </Button>
          </Link>
        </div>
      </div>

      <Footer />
    </main>
  )
}
