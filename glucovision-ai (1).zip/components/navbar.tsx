"use client"

import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Eye, Menu, X } from "lucide-react"
import { useState } from "react"

export default function Navbar() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)

  return (
    <nav className="bg-navy-dark/80 backdrop-blur-md border-b border-cyan-DEFAULT/20 sticky top-0 z-50">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center h-16">
          <Link href="/" className="flex items-center">
            <Eye className="h-8 w-8 text-cyan-DEFAULT mr-2" />
            <span className="text-xl font-bold text-white glow-text">GlucoVision AI</span>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-8">
            <Link href="/" className="text-gray-300 hover:text-cyan-light transition-colors">
              Home
            </Link>
            <Link href="/scan" className="text-gray-300 hover:text-cyan-light transition-colors">
              Scan
            </Link>
            <Link href="/upload" className="text-gray-300 hover:text-cyan-light transition-colors">
              Upload
            </Link>
            <Link href="/about" className="text-gray-300 hover:text-cyan-light transition-colors">
              About
            </Link>
            <Link href="/scan">
              <Button className="bg-cyan-DEFAULT hover:bg-cyan-dark text-white font-semibold rounded-lg glow-cyan transition-all duration-300">
                Get Started
              </Button>
            </Link>
          </div>

          {/* Mobile Menu Button */}
          <div className="md:hidden">
            <Button variant="ghost" size="icon" onClick={() => setIsMenuOpen(!isMenuOpen)} className="text-gray-300">
              {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </Button>
          </div>
        </div>
      </div>

      {/* Mobile Navigation */}
      {isMenuOpen && (
        <div className="md:hidden bg-navy-dark/95 backdrop-blur-md border-b border-cyan-DEFAULT/20">
          <div className="container mx-auto px-4 py-4 flex flex-col space-y-4">
            <Link
              href="/"
              className="text-gray-300 hover:text-cyan-light transition-colors py-2"
              onClick={() => setIsMenuOpen(false)}
            >
              Home
            </Link>
            <Link
              href="/scan"
              className="text-gray-300 hover:text-cyan-light transition-colors py-2"
              onClick={() => setIsMenuOpen(false)}
            >
              Scan
            </Link>
            <Link
              href="/upload"
              className="text-gray-300 hover:text-cyan-light transition-colors py-2"
              onClick={() => setIsMenuOpen(false)}
            >
              Upload
            </Link>
            <Link
              href="/about"
              className="text-gray-300 hover:text-cyan-light transition-colors py-2"
              onClick={() => setIsMenuOpen(false)}
            >
              About
            </Link>
            <Link href="/scan" onClick={() => setIsMenuOpen(false)}>
              <Button className="bg-cyan-DEFAULT hover:bg-cyan-dark text-white font-semibold w-full rounded-lg glow-cyan transition-all duration-300">
                Get Started
              </Button>
            </Link>
          </div>
        </div>
      )}
    </nav>
  )
}
