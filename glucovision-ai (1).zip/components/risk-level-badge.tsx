import { AlertTriangle, CheckCircle, AlertCircle } from "lucide-react"

interface RiskLevelBadgeProps {
  level: "low" | "medium" | "high"
}

export function RiskLevelBadge({ level }: RiskLevelBadgeProps) {
  const getBadgeContent = () => {
    switch (level) {
      case "low":
        return {
          icon: <CheckCircle className="h-8 w-8" />,
          label: "Low Risk",
          color: "bg-green-500/20 text-green-400 border-green-500/30",
          description: "No significant signs of diabetic retinopathy detected.",
        }
      case "medium":
        return {
          icon: <AlertCircle className="h-8 w-8" />,
          label: "Medium Risk",
          color: "bg-gold-DEFAULT/20 text-gold-DEFAULT border-gold-DEFAULT/30",
          description: "Early signs of diabetic retinopathy may be present.",
        }
      case "high":
        return {
          icon: <AlertTriangle className="h-8 w-8" />,
          label: "High Risk",
          color: "bg-red-500/20 text-red-400 border-red-500/30",
          description: "Significant signs of diabetic retinopathy detected.",
        }
      default:
        return {
          icon: <CheckCircle className="h-8 w-8" />,
          label: "Low Risk",
          color: "bg-green-500/20 text-green-400 border-green-500/30",
          description: "No significant signs of diabetic retinopathy detected.",
        }
    }
  }

  const { icon, label, color, description } = getBadgeContent()

  return (
    <div className={`rounded-lg p-6 border ${color} text-center`}>
      <div className="flex flex-col items-center">
        <div className="mb-2">{icon}</div>
        <h3 className="text-2xl font-bold mb-2">{label}</h3>
        <p className="text-sm">{description}</p>
      </div>
    </div>
  )
}
