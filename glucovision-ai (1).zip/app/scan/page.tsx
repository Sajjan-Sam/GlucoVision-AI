"use client"

import { useState, useRef, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Camera, RefreshCw, ArrowRight } from "lucide-react"
import Navbar from "@/components/navbar"
import Footer from "@/components/footer"
import { useRouter } from "next/navigation"
import { processImage } from "@/lib/image-processor"

export default function ScanPage() {
  const router = useRouter()
  const videoRef = useRef<HTMLVideoElement>(null)
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [isCameraActive, setIsCameraActive] = useState(false)
  const [capturedImage, setCapturedImage] = useState<string | null>(null)
  const [isProcessing, setIsProcessing] = useState(false)
  const [cameraError, setCameraError] = useState<string | null>(null)

  // Start camera
  const startCamera = async () => {
    setCameraError(null)
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: "user" },
        audio: false,
      })

      if (videoRef.current) {
        videoRef.current.srcObject = stream
        setIsCameraActive(true)
      }
    } catch (error) {
      console.error("Error accessing camera:", error)
      setCameraError("Unable to access camera. Please ensure you've granted camera permissions.")
    }
  }

  // Stop camera
  const stopCamera = () => {
    if (videoRef.current && videoRef.current.srcObject) {
      const stream = videoRef.current.srcObject as MediaStream
      const tracks = stream.getTracks()

      tracks.forEach((track) => {
        track.stop()
      })

      videoRef.current.srcObject = null
      setIsCameraActive(false)
    }
  }

  // Capture image
  const captureImage = () => {
    if (videoRef.current && canvasRef.current) {
      const video = videoRef.current
      const canvas = canvasRef.current

      // Set canvas dimensions to match video
      canvas.width = video.videoWidth
      canvas.height = video.videoHeight

      // Draw video frame to canvas
      const ctx = canvas.getContext("2d")
      if (ctx) {
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height)

        // Convert canvas to data URL
        const imageDataUrl = canvas.toDataURL("image/png")
        setCapturedImage(imageDataUrl)

        // Stop camera after capturing
        stopCamera()
      }
    }
  }

  // Reset camera
  const resetCamera = () => {
    setCapturedImage(null)
    startCamera()
  }

  // Process image and navigate to results
  const processAndNavigate = async () => {
    if (!capturedImage) return

    setIsProcessing(true)

    try {
      // Process the image (simulated)
      const results = await processImage(capturedImage)

      // Navigate to results page with the processed data
      router.push(`/results?data=${encodeURIComponent(JSON.stringify(results))}`)
    } catch (error) {
      console.error("Error processing image:", error)
      setIsProcessing(false)
    }
  }

  // Start camera on component mount
  useEffect(() => {
    startCamera()

    // Clean up on unmount
    return () => {
      stopCamera()
    }
  }, [])

  return (
    <main className="min-h-screen futuristic-gradient grid-pattern">
      <Navbar />

      <div className="container mx-auto px-4 py-12">
        <div className="max-w-3xl mx-auto">
          <h1 className="text-3xl md:text-4xl font-bold text-white glow-text text-center mb-8">Retinal Scan</h1>

          <p className="text-gray-300 text-center mb-12">
            Position your eye clearly in the camera frame for the most accurate results. Ensure you are in a well-lit
            environment.
          </p>

          <Card className="holographic-card overflow-hidden mb-8">
            <div className="aspect-video relative bg-navy-dark flex items-center justify-center">
              {!capturedImage ? (
                <>
                  <video
                    ref={videoRef}
                    autoPlay
                    playsInline
                    muted
                    className={`w-full h-full object-cover ${isCameraActive ? "block" : "hidden"}`}
                  />

                  {cameraError && (
                    <div className="absolute inset-0 flex items-center justify-center bg-navy-dark/80 p-6">
                      <div className="text-center">
                        <p className="text-red-400 mb-4">{cameraError}</p>
                        <Button onClick={startCamera} className="bg-cyan-DEFAULT hover:bg-cyan-dark text-navy-dark">
                          Try Again
                        </Button>
                      </div>
                    </div>
                  )}

                  {!isCameraActive && !cameraError && (
                    <div className="absolute inset-0 flex items-center justify-center bg-navy-dark/80">
                      <Button onClick={startCamera} className="bg-cyan-DEFAULT hover:bg-cyan-dark text-navy-dark">
                        <Camera className="mr-2 h-5 w-5" />
                        Start Camera
                      </Button>
                    </div>
                  )}
                </>
              ) : (
                <img
                  src={capturedImage || "/placeholder.svg"}
                  alt="Captured eye scan"
                  className="w-full h-full object-contain"
                />
              )}

              <canvas ref={canvasRef} className="hidden" />
            </div>
          </Card>

          <div className="flex justify-center space-x-4 mb-12">
            {isCameraActive && !capturedImage && (
              <Button
                onClick={captureImage}
                className="bg-cyan-DEFAULT hover:bg-cyan-dark text-white font-semibold px-6 py-5 text-lg rounded-lg glow-cyan transition-all duration-300"
              >
                <Camera className="mr-2 h-5 w-5" />
                Capture Image
              </Button>
            )}

            {capturedImage && (
              <>
                <Button
                  onClick={resetCamera}
                  variant="outline"
                  className="border-cyan-DEFAULT text-cyan-DEFAULT hover:text-cyan-light hover:border-cyan-light px-6 py-5 text-lg rounded-lg transition-all duration-300"
                >
                  <RefreshCw className="mr-2 h-5 w-5" />
                  Retake
                </Button>

                <Button
                  onClick={processAndNavigate}
                  disabled={isProcessing}
                  className="bg-cyan-DEFAULT hover:bg-cyan-dark text-white font-semibold px-6 py-5 text-lg rounded-lg glow-cyan transition-all duration-300"
                >
                  {isProcessing ? (
                    <>
                      <RefreshCw className="mr-2 h-5 w-5 animate-spin" />
                      Processing...
                    </>
                  ) : (
                    <>
                      <ArrowRight className="mr-2 h-5 w-5" />
                      Analyze Image
                    </>
                  )}
                </Button>
              </>
            )}
          </div>

          <div className="text-center text-gray-400 text-sm">
            <p className="mb-2">
              Your privacy is important to us. Images are processed securely and not stored permanently.
            </p>
            <p>
              <strong>Disclaimer:</strong> This is an experimental AI tool. Not a replacement for medical advice.
            </p>
          </div>
        </div>
      </div>

      <Footer />
    </main>
  )
}
